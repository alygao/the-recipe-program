package theRecipeProgram;

import java.io.Serializable;
import java.util.Iterator;

/**
 * SelfBalancingBinaryTree 
 * A self-balancing binary tree that will regularly update to be balanced whenever items are added, removed or edited
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class SelfBalancingBinaryTree<E extends Comparable<E>> implements Serializable, Iterable<E> {

	/**
	 * The root of the tree
	 */
	private BinaryTreeNode<E> root;

	/**
	 * add
	 * adds an item into the binary tree
	 * @param item the item being added
	 * @return true if item has been added
	 */
	public boolean add(E item) {
		root = add(item, root);
		refreshSeqNo(); // the sequence number of items now needs to be refreshed each time new item is added
		return true;
	}

	/**
	 * add
	 * adds an item into the binary tree while comparing the items value to other node's left and right child's items
	 * @param item the item being added
	 * @param node the node being checked
	 * @return node in which the item has been added to after it's been properly rotated
	 */
	private BinaryTreeNode<E> add(E item, BinaryTreeNode<E> node) {
		if ( node == null ) {
			node = new BinaryTreeNode<E>(item, null, null);
		} else if ( item.compareTo ( node.getItem() ) < 0 ) {
			node.setLeftChild( add ( item, node.getLeftChild()));
			if ( height(node.getLeftChild()) - height(node.getRightChild()) == 2) {
				if (item.compareTo(node.getLeftChild().getItem()) < 0) {
					node = rotateWithLeftChild(node);
				} else {
					node = doubleRotateWithLeftChild(node);
				}
			}
		} else if ( item.compareTo ( node.getItem() ) > 0 ) {
			node.setRightChild(add(item, node.getRightChild()));
			if (height(node.getRightChild()) - height(node.getLeftChild()) == 2)
				if ( item.compareTo ( node.getRightChild().getItem()) > 0 )
					node = rotateWithRightChild(node);
				else
					node = doubleRotateWithRightChild(node);
		}
		node.setHeight(max(height(node.getLeftChild()), height(node.getRightChild())) + 1);
		node.setNumOfChildren(numberOfChildren ( node.getLeftChild() ) + numberOfChildren (node.getRightChild()));
		return node;
	}
	
	/**
	 * clear
	 * Makes the tree empty 
	 */
	public void clear() {
		root = null;
	}
	
	/**
	 * get
	 * gets the item by index 
	 * @param index of the tree
	 * @return the item at the index (i.e., the sequence number)
	 */
	public E get(int index) {
		return getNodeByIndex(this.root, index).getItem();
	}
	
	/**
	 * getNodeByIndex
	 * gets the item by index by checking the node's sequence number
	 * @param node the node that is being checked if its sequence number equals the index
	 * @param index of the tree
	 * @return the node whose sequence number matches the index
	 */
	public BinaryTreeNode<E> getNodeByIndex(BinaryTreeNode<E> node, int index) {
		if ( node.getSeqNo() == index ) {
			return node;
		} else if ( index < node.getSeqNo() ) {
			return getNodeByIndex ( node.getLeftChild(), index );
		} else {
			return getNodeByIndex ( node.getRightChild(), index );
		}
	}
	
	/**
	 * size
	 * counts the number of nodes
	 * @return the size of the tree, i.e., the number of nodes.
	 */
	public int size() {
		if (root == null) {
			return 0;
		} else {
			return 1 + counter(root);
		}
	}
	
	/**
	 * contains
	 * sees if the tree contains the object/item
	 * @param o the object being checked
	 * @return true if the tree contains the object/item
	 */
	public boolean contains(Object o) {
		try {
			E e = (E) o;
			return search ( e );
		} catch (ClassCastException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * isEmpty
	 * sees if the tree is empty
	 * @return true if the tree is empty
	 */
	public boolean isEmpty() {
		return (root == null);
	}
	
	/**
	 * remove
	 * removes the node by index
	 * @param index the index of the node
	 * @return the item being removed
	 */
	public E remove(int index) {
		BinaryTreeNode<E> nodeToBeRemoved = getNodeByIndex(root, index);
		if ( nodeToBeRemoved == null ) {
			return null;
		}
		BinaryTreeNode<E> newRoot = root;
		this.root = null;
		if (newRoot != null) {
			addWithout(newRoot, index);
		}
		return nodeToBeRemoved.getItem();
	}
	
	/**
	 * remove
	 * removes the node by object/item
	 * @param o the object/item being removed
	 * @return true if item is removed
	 */
	public boolean remove(Object o) {
		try {
			E item = (E) o;
			BinaryTreeNode<E> nodeToBeRemoved = find ( item );
			if ( nodeToBeRemoved == null ) {
				return false;
			}
			BinaryTreeNode<E> newRoot = root;
			this.root = null;
			if (newRoot != null) {
				addWithout(newRoot, nodeToBeRemoved.getSeqNo() );
			}
			refreshSeqNo ( );
			return true;
		} catch (ClassCastException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * set
	 * using the index to find the node, it sets the the node with a new item value
	 * @param index the index of the node
	 * @param item the item to set to the position indicated by the index.
	 * @return the item previously at the specified position
	 */
	public E set(int index, E item) {
		BinaryTreeNode<E> nodeToReplaceData = getNodeByIndex(root, index);
		if ( nodeToReplaceData == null ) {
			return null;
		} else {
			nodeToReplaceData.setItem(item);
		}
		
		reconstructTree ( );
		refreshSeqNo ( );
		return nodeToReplaceData == null ? null : nodeToReplaceData.getItem();
	}

	// ========== HELPER METHODS ==========
	
	/**
	 * refreshSeqNo
	 * refreshes the sequence number of each Node in the tree.
	 */
	private void refreshSeqNo() {
		calculateSeqNo(root, 0);
	}

	/**
	 * calculateSeqNo
	 * calculates the sequence number for all nodes
	 * @param node the node and all child nodes that will be calculated the sequence number.
	 * @param seqNo the sequence number
	 * @return the sequence number
	 */
	private int calculateSeqNo(BinaryTreeNode<E> node, int seqNo) {

		if (node != null) {
			int maxChildSeqNo = calculateSeqNo(node.getLeftChild(), seqNo);
			node.setSeqNo(maxChildSeqNo);
			return calculateSeqNo(node.getRightChild(), node.getSeqNo() + 1);
		} else {
			return seqNo;
		}

	}

	/**
	 * reconstructTree
	 * reconstructs tree to make it self-balanced. It is normally used after a node's value is updated. 
	 */
	private void reconstructTree() {
		BinaryTreeNode<E> newRoot = root;
		this.root = null;
		if (newRoot != null) {
			reconstructTree (newRoot );
		}
	}

	/**
	 * reconstructTree
	 * reconstructs tree to make it self-balanced recursively. 
	 * @param node the node currently being re-added and later given a new sequence number
	 */
	public void reconstructTree(BinaryTreeNode<E> node) {
		if ( node != null ) {
			reconstructTree(node.getLeftChild());
			add ( node.getItem() );
			reconstructTree(node.getRightChild());
		}
	}
	
	/**
	 * addWithout
	 * add a node into the tree except the seqNo equals to index. It is normally used for reconstructing the tree after removing a node
	 * @param node the node to add to the new tree.
	 * @param index indicates the node that will not be added to the tree.
	 */
	public void addWithout(BinaryTreeNode<E> node, int index) {
		if ( node != null ) {
			addWithout(node.getLeftChild(), index);
			if ( node.getSeqNo() != index ) {
				add ( node.getItem() );
			}
			addWithout(node.getRightChild(), index);
		}
	}
	
	/**
	 * find
	 * find the node by item
	 * @param item used to search for its corresponding node
	 * @return the node that contains the item
	 */
	public BinaryTreeNode<E> find(E item) {
		return find(root, item);
	}
	
	/**
	 * find
	 * find the node that contains the specified item
	 * @param node the node that is currently being checked if its item matches the item
	 * @param item used to search for its corresponding node
	 * @return the node that contains the item
	 */
	private BinaryTreeNode<E> find(BinaryTreeNode<E> node, E item) {
		BinaryTreeNode<E> foundNode = null;
		while ((node != null) ) {
			E nodeValue = node.getItem();
			if (item.compareTo(nodeValue) < 0 )
				node = node.getLeftChild();
			else if (item.compareTo(nodeValue) > 0 )
				node = node.getRightChild();
			else {
				foundNode = node;
				break;
			}
			foundNode = find(node, item);
		}
		return foundNode;
	}
	
	/**
	 * search
	 * searches tree if it contains the item (helper method for contains())
	 * @param item he item being searched for
	 * @return true if search is successful
	 */
	public boolean search(E item) {
		return search(root, item);
	}
	
	/**
	 * search
	 * searches tree if it contains the item (helper method for contains())
	 * @param node the node that is being checked
	 * @param item the item being searched for
	 * @return true if search is successful
	 */
	private boolean search(BinaryTreeNode<E> node, E item) {
		boolean found = false;
		while ((node != null) && !found) {
			E nodeItem = node.getItem();
			if (item.compareTo(nodeItem) < 0 )
				node = node.getLeftChild();
			else if (item.compareTo(nodeItem) > 0 )
				node = node.getRightChild();
			else {
				found = true;
				break;
			}
			found = search(node, item);
		}
		return found;
	}
	
	/**
	 * counter
	 * helper method for size that counts all nodes other than root
	 * @param node the node that is being checked
	 * @return the number of nodes excluding root
	 */
	public int counter(BinaryTreeNode<E> node) {
		if (node.isLeaf()) {
			return 0;
		} else {
			if ((node.getLeftChild() != null) && (node.getRightChild() != null)) {
				return 2 + counter(node.getLeftChild()) + counter(node.getRightChild());
			} else if (node.getRightChild() != null) {
				return 1 + counter(node.getRightChild());
			} else {
				return 1 + counter(node.getLeftChild());

			}
		}
	}
	

	/**
	 * height
	 * calculate the height of the node within the tree
	 * @param node the node whose height is being checked
	 * @return the height of the node within the tree
	 */
	private int height(BinaryTreeNode<E> node) {
		return node == null ? -1 : node.getHeight();
	}
	
	/**
	 * max
	 * gets the max height of left/right node 
	 * @param leftNodeHeight the height of the left node
	 * @param rightHeightNode the height of the right node
	 * @return the max height between the left and right node
	 */
	private int max(int leftNodeHeight, int rightHeightNode) {
		return leftNodeHeight > rightHeightNode ? leftNodeHeight : rightHeightNode;
	}
	
	/**
	 * numberOfChildren
	 * calculate number of children that the node has recursively
	 * @param node the node whose children are being counted
	 * @return the number of children
	 */
	private int numberOfChildren(BinaryTreeNode<E> node) {
		return node == null ? 0 : numberOfChildren ( node.getLeftChild() ) + numberOfChildren ( node.getRightChild() ) + 1;
	}

	/**
	 * rotateWithLeftChild
	 * Single-Rotation for an unbalanced node with deeper nodes on the left. 
	 * @param node the node that is not balanced (i.e., whose left child's height is different from the right child's height by 2.)
	 * @return the new node that takes the position of the original node after the rotation.
	 */
	private BinaryTreeNode<E> rotateWithLeftChild(BinaryTreeNode<E> node) {
		BinaryTreeNode<E> tempNode = node.getLeftChild();
		node.setLeftChild(tempNode.getRightChild());
		tempNode.setRightChild(node);
		node.setHeight(max(height(node.getLeftChild()), height(node.getRightChild())) + 1);
		tempNode.setHeight(max(height(tempNode.getLeftChild()), node.getHeight()) + 1);
		return tempNode;
	}

	/**
	 * rotateWithRightChild
	 * Single-Rotation for an unbalanced node with deeper nodes on the right. 
	 * @param node the node that is not balanced (i.e., whose left child's height is different from the right child's height by 2.)
	 * @return the new node that takes the position of the original node after the rotation.
	 */
	private BinaryTreeNode<E> rotateWithRightChild(BinaryTreeNode<E> node) {
		BinaryTreeNode<E> tempNode = node.getRightChild();
		node.setRightChild(tempNode.getLeftChild());
		tempNode.setLeftChild(node);
		node.setHeight(max(height(node.getLeftChild()), height(node.getRightChild())) + 1);
		tempNode.setHeight(max(height(tempNode.getRightChild()), node.getHeight()) + 1);
		return tempNode;
	}
	
	/**
	 * doubleRotateWithLeftChild
	 * Double-Rotation for an unbalanced node with deeper nodes on the left's right. 
	 * @param node the node that is not balanced (i.e., whose left child's height is different from the right child's height by 2.)
	 * @return the new node that takes the position of the original node after the rotation.
	 */
	private BinaryTreeNode<E> doubleRotateWithLeftChild(BinaryTreeNode<E> node) {
		node.setLeftChild(rotateWithRightChild(node.getLeftChild()));
		return rotateWithLeftChild(node);
	}

	/**
	 * doubleRotateWithRightChild
	 * Double-Rotation for an unbalanced node with deeper nodes on the right's left. 
	 * @param node the node that is not balanced (i.e., whose left child's height is different from the right child's height by 2.)
	 * @return the new node that takes the position of the original node after the rotation.
	 */
	private BinaryTreeNode<E> doubleRotateWithRightChild(BinaryTreeNode<E> node) {
		node.setRightChild(rotateWithLeftChild(node.getRightChild()));
		return rotateWithRightChild(node);
	}
	
	/**
	 * getRoot
	 * gets the root of the binary tree
	 * @return the root node
	 */
	public BinaryTreeNode<E> getRoot() {
		return this.root;
	}

	/**
	 * Returns an Iterator&lt;E&gt; object.
	 * @return an Iterator&lt;E&gt; object.
	 */
	@Override
	public Iterator<E> iterator() {
		return new SBTreeIterator<>( this );
	}
}

/**
 * SBTreeIterator 
 * An implementation of Iterator that iterates through the binary tree
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */
class SBTreeIterator<E extends Comparable<E>> implements Iterator<E> {
	
	/**
	 * the current index that the iterator starts with
	 */
	private int index = 0;
	
	/**
	 * the binary tree that the iterator is iterating through 
	 */
	private SelfBalancingBinaryTree<E> tree;
	
	/**
	 * construtor to initialize the binary tree
	 * @param tree the binary tree to be iterated through
	 */
	public SBTreeIterator(SelfBalancingBinaryTree<E> tree) {
		this.tree = tree;
	}

	@Override
	/**
	 * hasNext
	 * sees if there are more elements
	 * @return true if there are more elements
	 */
	public boolean hasNext() {
		return this.index < this.tree.size();
	}

	@Override
	/**
	 * next
	 * finds the next item in the iteration
	 * @return the next item
	 */
	public E next() {
		E currentNodeValue = null;
		if ( this.index < this.tree.size() ) {
			currentNodeValue = tree.get(this.index++);
		}
		return currentNodeValue;
	}
	
}

/**
 * BinaryTreeNode 
 * A node that is to be used in the binary tree
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */
class BinaryTreeNode<E> implements Serializable {
	
	/**
	 * the item being stored in the node
	 */
	private E item;
	
	/**
	 * the node's left child
	 */
	private BinaryTreeNode<E> left;
	
	/**
	 * the node's right child
	 */
	private BinaryTreeNode<E> right;
	
	/**
	 * the height of the node
	 */
	private int height;
	
	/**
	 * the number of children the node has
	 */
	private int numOfChildren;
	
	/**
	 * the sequence number of the node in the tree
	 */
	private int seqNo;

	/**
	 * constructor to initialize all characteristics of a node
	 * @param item the value the node is holding
	 * @param left the node's left child
	 * @param right the node's right child
	 */
	public BinaryTreeNode(E item, BinaryTreeNode<E> left, BinaryTreeNode<E> right) {
		this.item = item;
		this.left = null;
		this.right = null;
		this.height = 0;
		this.numOfChildren = 0;
		this.seqNo = 0;
	}

	/**
	 * getLeftChild
	 * gets the node's left child
	 * @return node's left child
	 */
	public BinaryTreeNode<E> getLeftChild() {
		return this.left;
	}

	/**
	 * getRightChild
	 * gets the node's right child
	 * @return node's right child
	 */
	public BinaryTreeNode<E> getRightChild() {
		return this.right;
	}

	/**
	 * setLeftChild
	 * sets the node's left child
	 * @param left node's left child
	 */
	public void setLeftChild(BinaryTreeNode<E> left) {
		this.left = left;
	}

	/**
	 * setRightChild
	 * sets the node's right child
	 * @param right node's right child
	 */
	public void setRightChild(BinaryTreeNode<E> right) {
		this.right = right;
	}

	/**
	 * getItem
	 * gets the item that the node is storing
	 * @return the item that the node is storing
	 */
	public E getItem() {
		return this.item;
	}

	/**
	 * setItem
	 * sets the item that the node is storing
	 * @param item the item that the node is storing
	 */
	public void setItem(E item) {
		this.item = item;
	}

	/**
	 * isLeaf
	 * checks if the node is a leaf
	 * @return true if node is leaf
	 */
	public boolean isLeaf() {
		if (this.getLeftChild() == null && this.getRightChild() == null) {
			return true;
		}
		return false;
	}

	/**
	 * getHeight
	 * gets the node's height
	 * @return the node's height
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * setHeight
	 * sets the node's height
	 * @param height the node's height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * getNumOfChildren
	 * gets the node's number of children
	 * @return the node's number of children
	 */
	public int getNumOfChildren() {
		return numOfChildren;
	}

	/**
	 * setNumOfChildren
	 * sets the node's number of children
	 * @param numOfChildren the node's number of children
	 */
	public void setNumOfChildren(int numOfChildren) {
		this.numOfChildren = numOfChildren;
	}

	/**
	 * getSeqNo
	 * gets the node's sequence number
	 * @return the node's sequence number
	 */
	public int getSeqNo() {
		return seqNo;
	}

	/**
	 * setSeqNo
	 * sets the node's sequence number
	 * @param seqNo the node's sequence number
	 */
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}

	@Override
	/**
	 * Returns a string representation of the BinaryTreeNode class.
	 * @return a string representation of the BinaryTreeNode class.
	 */
	public String toString() {
		return "BinaryTreeNode [item=" + item + ", height=" + height
				+ ", numOfChildren=" + numOfChildren + ", seqNo=" + seqNo + ", left=" + left + ", right=" + right + "]";
	}
	
	
	
}
