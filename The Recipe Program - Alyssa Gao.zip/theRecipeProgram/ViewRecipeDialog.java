package theRecipeProgram;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * ViewRecipeDialog 
 * The dialog that will open when viewing recipes
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */
public class ViewRecipeDialog extends JDialog {

	/**
	 * stores all recipes that have been added and will be used to display them in the recipe table
	 */
	private RecipeDatabase recipeDatabase;
	
	/**
	 * reference this dialog as 'selfDialog'
	 */
	private JDialog selfDialog = this;

	/**
	 * Button to add new recipe 
	 */
	private JButton addNewRecipeButton;
	
	/**
	 * Button to modify recipe 
	 */
	private JButton modifyRecipeButton;
	
	/**
	 * Button to delete recipe 
	 */
	private JButton deleteRecipeButton;
	
	/**
	 * Button to add recipe to shopping list
	 */
	private JButton addToShoppingListButton;

	/**
	 * Button to view ingredients
	 */
	private JButton viewIngredientsButton;
	
	/**
	 * Button to view shopping list
	 */
	private JButton viewShoppingListButton;

	/**
	 * Label that states recipe's name
	 */
	private JLabel displayRecipeName;
	
	/**
	 * Label that states recipe's preparation time
	 */
	private JLabel displayRecipePrepTime;
	
	/**
	 * Label that states recipe's cook time
	 */
	private JLabel displayRecipeCookTime;
	
	/**
	 * Text Panel that states recipe's instructions
	 */
	private JTextPane displayRecipeInstructionsPanel;
	
	/**
	 * Check Box that indicates if recipe is a favourite
	 */
	private JCheckBox displayIsFavourite;
	
	/**
	 * Check Box that indicates if recipe is vegetarian
	 */
	private JCheckBox displayIsVegetarian;
	
	/**
	 * Label that states recipe's food category
	 */
	private JLabel displayFoodCategory;
	
	/**
	 * Label that shows recipe's image
	 */
	private JLabel displayRecipeImage;

	/**
	 * Table used to display recipes
	 */
	private JTable recipesListTable;
	
	/**
	 * Table model used to display recipes
	 */
	private RecipeListTableModel recipesListTableModel;
	
	/**
	 * the background image for the dialog
	 */
	private ImageIcon background = null;

	/**
	 * constructor that initializes the user interface and recipe database
	 * @param recipeDatabase stores the recipes in a binary tree which will be used to view recipes
	 */
	public ViewRecipeDialog(RecipeDatabase recipeDatabase) {
		this.recipeDatabase = recipeDatabase;
		initUI();
	}

	/**
	 * initUI 
	 * Initializes the panel's attributes and loads the background image
	 */
	private void initUI() {

		setModalityType(ModalityType.APPLICATION_MODAL);

		setDefaultLookAndFeelDecorated(true);
		setTitle("View Recipes");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		getContentPane().add(panel);
		
		background = new ImageIcon(getClass().getResource("pink background 1.JPG"));
		JLabel backgroundLabel = new JLabel ();
		backgroundLabel.setIcon(background);
		backgroundLabel.setBounds(0, 0, 1000, 600);

		recipesListTableModel = new RecipeListTableModel();
		recipesListTable = new JTable(recipesListTableModel);
		recipesListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		recipesListTable.setBounds(25, 50, 400, 400);
		recipesListTableModel.addRows(recipeDatabase.getRecipeList());

		JScrollPane recipeListScrollPane = new JScrollPane(recipesListTable);
		recipeListScrollPane.setBounds(25, 50, 400, 400);
		panel.add(recipeListScrollPane);

		addNewRecipeButton = new JButton("Add");
		addNewRecipeButton.setBounds(25, 500, 100, 30);
		addNewRecipeButton.addActionListener(new ButtonListener());
		panel.add(addNewRecipeButton);

		modifyRecipeButton = new JButton("Modify");
		modifyRecipeButton.setBounds(175, 500, 100, 30);
		panel.add(modifyRecipeButton);
		modifyRecipeButton.addActionListener(new ButtonListener());

		deleteRecipeButton = new JButton("Delete");
		deleteRecipeButton.setBounds(325, 500, 100, 30);
		panel.add(deleteRecipeButton);
		deleteRecipeButton.addActionListener(new ButtonListener());

		recipesListTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			/**
			 * valueChanged
			 * called whenever a value changes
			 * @param e the event that characterizes the change
			 */
			public void valueChanged(ListSelectionEvent e) {
				if (e.getValueIsAdjusting())
					return;

				ListSelectionModel lsm = (ListSelectionModel) e.getSource();

				if (!lsm.isSelectionEmpty()) {
					int selectedRow = lsm.getMinSelectionIndex();
					if ( selectedRow >= recipesListTable.getRowCount() ) {
						return;
					}
					Recipe selectedRecipe = recipesListTableModel.getData().get(selectedRow);
					displayRecipe(selectedRecipe);
				}
			}
		});

		// ---------------------- components for displaying selected recipe
		// ----------------------

		viewIngredientsButton = new JButton("View Ingredients");
		viewIngredientsButton.setBounds(825, 210, 150, 30);
		viewIngredientsButton.addActionListener(new ButtonListener());

		JLabel displayRecipeNameLabel = new JLabel("Recipe Name:");
		displayRecipeNameLabel.setBounds(500, 50, 100, 30);
		displayRecipeName = new JLabel();
		displayRecipeName.setBounds(600, 50, 100, 30);

		JLabel displayRecipePrepTimeLabel = new JLabel("Prep Time:");
		displayRecipePrepTimeLabel.setBounds(500, 90, 100, 30);
		displayRecipePrepTime = new JLabel();
		displayRecipePrepTime.setBounds(600, 90, 100, 30);

		JLabel displayRecipeCookTimeLabel = new JLabel("Cook Time:");
		displayRecipeCookTimeLabel.setBounds(500, 130, 100, 30);
		displayRecipeCookTime = new JLabel();
		displayRecipeCookTime.setBounds(600, 130, 100, 30);

		JLabel displayRecipeInstructionsLabel = new JLabel("Instructions: ");
		displayRecipeInstructionsLabel.setBounds(500, 170, 100, 30);
		displayRecipeInstructionsPanel = new JTextPane();
		displayRecipeInstructionsPanel.setBounds(500, 200, 300, 100);
		displayRecipeInstructionsPanel.setEditable(false);
		
		JScrollPane instructionsScrollPane = new JScrollPane(displayRecipeInstructionsPanel);
		instructionsScrollPane.setBounds(500, 200, 300, 100);
		panel.add(instructionsScrollPane);

		displayIsFavourite = new JCheckBox("Favourite");
		displayIsFavourite.setBounds(500, 310, 100, 30);
		displayIsFavourite.setEnabled(false);

		displayIsVegetarian = new JCheckBox("Vegetarian");
		displayIsVegetarian.setBounds(610, 310, 100, 30);
		displayIsVegetarian.setEnabled(false);

		displayRecipeImage = new JLabel();
		displayRecipeImage.setBounds(825, 50, 150, 150);

		JLabel displayFoodCategoryLabel = new JLabel("Food Category:");
		displayFoodCategoryLabel.setBounds(500, 340, 100, 30);
		displayFoodCategory = new JLabel();
		displayFoodCategory.setBounds(600, 340, 100, 30);

		addToShoppingListButton = new JButton("Add to Shopping List");
		addToShoppingListButton.setBounds(825, 250, 150, 30);
		addToShoppingListButton.addActionListener(new ButtonListener());

		viewShoppingListButton = new JButton("View Shopping List");
		viewShoppingListButton.setBounds(825, 330, 150, 30);
		viewShoppingListButton.addActionListener(new ButtonListener());

		panel.add(viewIngredientsButton);
		panel.add(displayRecipeNameLabel);
		panel.add(displayRecipeName);
		panel.add(displayRecipePrepTimeLabel);
		panel.add(displayRecipePrepTime);
		panel.add(displayRecipeCookTimeLabel);
		panel.add(displayRecipeCookTime);
		panel.add(displayRecipeInstructionsLabel);
		panel.add(displayRecipeInstructionsPanel);
		panel.add(displayIsFavourite);
		panel.add(displayIsVegetarian);
		panel.add(displayFoodCategoryLabel);
		panel.add(displayFoodCategory);
		panel.add(displayRecipeImage);
		panel.add(addToShoppingListButton);
		panel.add(viewShoppingListButton);
		
		instructionsScrollPane.getViewport().add(this.displayRecipeInstructionsPanel);
		panel.add(instructionsScrollPane);
		panel.add (backgroundLabel);
		setVisible(true);
	}

	public void displayRecipe(Recipe recipe) {
		displayRecipeName.setText(recipe == null ? "" : recipe.getRecipeName());
		displayRecipePrepTime.setText(recipe == null ? "" : Integer.toString(recipe.getPrepTime()) + " minutes");
		displayRecipeCookTime.setText(recipe == null ? "" : Integer.toString(recipe.getCookTime()) + " minutes");
		displayRecipeInstructionsPanel.setText(recipe == null ? "" : recipe.getInstructions());
		displayIsFavourite.setSelected(recipe == null ? false : recipe.isFavourite());
		displayIsVegetarian.setSelected(recipe == null ? false : recipe.isVegetarian());
		displayFoodCategory.setText(recipe == null ? "" : recipe.getFoodCategory());
		displayRecipeImage.setIcon(recipe == null ? null : recipe.getImage());
	}

	/**
	 * ButtonListener 
	 * inner class that checks which button was pressed and executes the corresponding action
	 * @author Alyssa Gao
	 * @version 1.0
	 * @since May 5, 2019
	 */
	class ButtonListener implements ActionListener {

		/**
		 * actionPerformed 
		 * performs the action that is needed to be performed from clicking a button
		 * @param press used to determine which button is pressed
		 */
		public void actionPerformed(ActionEvent press) {
			if (press.getSource() == addNewRecipeButton) {
				AddRecipeDialog addRecipeDialog = new AddRecipeDialog(recipeDatabase, recipesListTableModel);
//				addRecipeDialog.setVisible(true);
			} else if (press.getSource() == deleteRecipeButton) {
				int selectedRow = recipesListTable.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(selfDialog, "Please choose a recipe to delete.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				for (int i = 0; i < recipeDatabase.getShoppingList().size(); i++) {
					if (recipeDatabase.getShoppingList().get(i).getRecipe().getRecipeName().equals((recipeDatabase.getRecipeList().get(selectedRow).getRecipeName()))) {
						JOptionPane.showMessageDialog(selfDialog, "Recipe must be first removed from your shopping list in order to delete it",
								"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}

				int response = JOptionPane.showConfirmDialog(selfDialog, "Are you sure you want to delete this recipe?",
						"Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				if (response == JOptionPane.NO_OPTION) {
					return;
				} else if (response == JOptionPane.YES_OPTION) {
					recipesListTableModel.removeRow(selectedRow);
					recipeDatabase.getRecipeList().remove(selectedRow);
				} else if (response == JOptionPane.CLOSED_OPTION) {
					return;
				}
				
				displayRecipe( null );
				
			} else if (press.getSource() == modifyRecipeButton) {
				int selectedRow = recipesListTable.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(selfDialog, "Please choose a recipe to modify.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				for (int i = 0; i < recipeDatabase.getShoppingList().size(); i++) {
					if (recipeDatabase.getShoppingList().get(i).getRecipe().getRecipeName().equals((recipeDatabase.getRecipeList().get(selectedRow).getRecipeName()))) {
						JOptionPane.showMessageDialog(selfDialog, "Recipe must be first removed from your shopping list in order to modify it.",
								"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}
				
				ModifyRecipeDialog modifyRecipeDialog = new ModifyRecipeDialog(recipeDatabase, recipesListTableModel,
						selectedRow);
				
				displayRecipe( recipesListTableModel.getData().get(selectedRow) );

			} else if (press.getSource() == viewIngredientsButton) {
				int selectedRow = recipesListTable.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(selfDialog, "Please choose a recipe to view its ingredients.",
							"Error", JOptionPane.ERROR_MESSAGE);
					return;
				}

				ViewIngredientsDialog viewIngredientsDialog = new ViewIngredientsDialog(
						recipeDatabase.getRecipeList().get(selectedRow));

			} else if (press.getSource() == addToShoppingListButton) {
				int selectedRow = recipesListTable.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(selfDialog, "Please choose a recipe to add to your shopping list.",
							"Error", JOptionPane.ERROR_MESSAGE);
					return;
				}

				for (int i = 0; i < recipeDatabase.getShoppingList().size(); i++) {
					if ((recipeDatabase.getShoppingList().get(i).getRecipe().getRecipeName()).equals(((recipeDatabase.getRecipeList().get(selectedRow).getRecipeName())))) {
						JOptionPane.showMessageDialog(selfDialog, "Recipe is already added in your shopping list.",
								"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}

				recipeDatabase.getShoppingList()
						.add(new ShoppingRecipe(recipeDatabase.getRecipeList().get(selectedRow)));

			} else if (press.getSource() == viewShoppingListButton) {

				if (recipeDatabase.getShoppingList().size() == 0) {
					JOptionPane.showMessageDialog(null, "You have added no recipes to your shopping list.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				dispose();
				ShoppingListDialog shoppingListDialog = new ShoppingListDialog(recipeDatabase);
			}
		}
	}
}
