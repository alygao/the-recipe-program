package theRecipeProgram;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * TheRecipeProgram 
 * The main program for the recipe program
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class TheRecipeProgram extends JFrame {

	/**
	 * The panel that displays the menu and instructions to use program
	 */
	private JPanel mainPanel;

	/**
	 * Stores the recipes in a binary tree that will be passed around to different
	 * dialogs
	 */
	private RecipeDatabase recipeDatabase = new RecipeDatabase();

	/**
	 * The background image displaying instructions to use in the program
	 */
	private ImageIcon menuBackground = null;

	/**
	 * The image displayed with the exit option
	 */
	private ImageIcon iconExit = null;

	/**
	 * The image displayed with the open file option
	 */
	private ImageIcon iconOpen = null;

	/**
	 * The image displayed with the save option
	 */
	private ImageIcon iconSave = null;
	
	/**
	 * The constructor of TheRecipeProgram class. It initializes the program UI 
	 */
	public TheRecipeProgram() {
		initUI();
	}

	/**
	 * initUI 
	 * Initializes the panel's attributes and loads the background image
	 */
	public void initUI() {

		mainPanel = new JPanel();
		mainPanel.setLayout(null);
		getContentPane().add(mainPanel);

		setJMenuBar(createMenu());

		setDefaultLookAndFeelDecorated(true);
		setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("recipe icon.png")));
		setTitle("Recipe Database");
		setSize(1000, 600);
		setResizable(false);
		setLocationRelativeTo(null);

		menuBackground = new ImageIcon(getClass().getResource("menu background.JPG"));

		JLabel titleLabel = new JLabel();
		titleLabel.setIcon(menuBackground);
		add(titleLabel);

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

		addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowEvent) {
				closeApplication();
			}
		});

		loadConfigurationAndData();
	}

	/**
	 * closeApplication 
	 * Asks if the user is sure they want to close the program. If
	 * yes, it will automatically save the data.
	 */
	protected void closeApplication() {
		int ret = JOptionPane.showConfirmDialog(mainPanel, "Are you sure you want to close the application?",
				"Close Application", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (ret == JOptionPane.YES_OPTION) {
			saveConfigurationAndData();
			System.exit(0);
		}
	}

	/**
	 * openDataFile 
	 * Opens user's own file explorer and allows user to choose a data
	 * file the file to be opened that was previously saved from before
	 */
	protected void openDataFile() {
		JFileChooser fileopen = new JFileChooser();
		FileFilter filter = new FileNameExtensionFilter("Application data files", ".rdb");
		fileopen.addChoosableFileFilter(filter);

		int ret = fileopen.showDialog(mainPanel, "Open file");
		if (ret == JFileChooser.APPROVE_OPTION) {
			File file = fileopen.getSelectedFile();
			try {
				loadDataFile(file);
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null, "The file name could not be found.", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;

			} catch (IOException e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null, "The file cannot be used with this program.", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
	}

	/**
	 * loadDataFile 
	 * load the RecipeDatabase from the file specified by the filename.
	 * @param filename the file name of the database file.
	 * @throws FileNotFoundException if the file cannot be found
	 * @throws IOException if there is an error in reading the file
	 * @throws ClassNotFoundException the RecipeDatabase class cannot be found.
	 * @throws ClassCastException the data stored in the file is not a RecipeDatabase object
	 */
	private void loadDataFile(String filename) throws FileNotFoundException, IOException, ClassNotFoundException, ClassCastException {
		loadDataFile(new File(filename));
	}

	/**
	 * loadDataFile 
	 * load the RecipeDatabase from the file specified.
	 * @param file the File object defining the database file.
	 * @throws FileNotFoundException if the file cannot be found
	 * @throws IOException if there is an error in reading the file
	 * @throws ClassNotFoundException the RecipeDatabase class cannot be found.
	 * @throws ClassCastException the data stored in the file is not a RecipeDatabase object
	 */
	private void loadDataFile(File file) throws FileNotFoundException, IOException, ClassNotFoundException, ClassCastException {
		this.configuration.setProperty("database.filename", file.getAbsolutePath());
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
			recipeDatabase = (RecipeDatabase) ois.readObject();
		}
	}

	/**
	 * saveDataFile 
	 * save data file saves the file under its own unique extension
	 */
	protected void saveDataFile() {
		JFileChooser filesave = new JFileChooser();
		FileFilter filter = new FileNameExtensionFilter("Application data files", ".rdb");
		filesave.addChoosableFileFilter(filter);

		int ret = filesave.showDialog(mainPanel, "Save file");
		if (ret == JFileChooser.APPROVE_OPTION) {
			File file = filesave.getSelectedFile();
			saveDataFile(file);
		}
	}

	/**
	 * saveDataFile
	 * converts the String filename into a file
	 * @param filename the name of the file to be saved
	 */
	private void saveDataFile(String filename) {
		saveDataFile(new File(filename));
	}

	/**
	 * saveDataFile
	 * saves the data into a file
	 * @param file the file which will hold the saved data
	 */
	private void saveDataFile(File file) {
		this.configuration.setProperty("database.filename", file.getAbsolutePath());
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
			oos.writeObject(recipeDatabase);
		} catch (IOException e1) {
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "The file cannot be used with this program.", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * createMenu
	 * creates the menu bar
	 * @return a JMenuBar object that contains all JMenu and JMenuItem objects.
	 */
	protected JMenuBar createMenu() {
		JMenuBar menubar = new JMenuBar();

		// Initializes the images that are linked to each image in the menu bar
		iconExit = new ImageIcon(getClass().getResource("exit.png"));
		iconOpen = new ImageIcon(getClass().getResource("open.png"));
		iconSave = new ImageIcon(getClass().getResource("save.png"));

		JMenu file = new JMenu("File");
		file.setMnemonic(KeyEvent.VK_F);

		// Open File
		JMenuItem fileOpen = new JMenuItem("Open", iconOpen);
		fileOpen.setMnemonic(KeyEvent.VK_O);
		fileOpen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				openDataFile();
			}
		});

		// Save File
		JMenuItem fileSave = new JMenuItem("Save", iconSave);
		fileSave.setMnemonic(KeyEvent.VK_S);
		fileSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				saveDataFile();
			}
		});

		// Exit File
		JMenuItem eMenuItem = new JMenuItem("Exit", iconExit);
		eMenuItem.setMnemonic(KeyEvent.VK_E);
		eMenuItem.setToolTipText("Exit application");
		eMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				closeApplication();
			}
		});

		file.add(fileOpen);
		file.add(fileSave);
		file.add(eMenuItem);
		menubar.add(file);

		// -------- View Recipe ---------
		JMenu viewRecipe = new JMenu("Recipe");
		viewRecipe.setMnemonic(KeyEvent.VK_R);
		menubar.add(viewRecipe);

		JMenuItem recipeMenuItem = new JMenuItem("View Recipes");
		recipeMenuItem.setMnemonic(KeyEvent.VK_E);
		viewRecipe.add(recipeMenuItem);

		recipeMenuItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				ViewRecipeDialog viewRecipeDialog = new ViewRecipeDialog(recipeDatabase);

			}
		});

		// -------- Shopping List ---------

		JMenu shoppingListMenu = new JMenu("Shopping List");
		shoppingListMenu.setMnemonic(KeyEvent.VK_S);
		menubar.add(shoppingListMenu);

		JMenuItem shoppingListMenuItem = new JMenuItem("View Shopping List");
		recipeMenuItem.setMnemonic(KeyEvent.VK_E);
		shoppingListMenu.add(shoppingListMenuItem);

		shoppingListMenuItem.addActionListener(new ActionListener() {

			@Override
			/**
			 * actionPerformed 
			 * performs the action that is needed to be performed from clicking a button
			 * @param e the action performed
			 */
			public void actionPerformed(ActionEvent e) {

				if (recipeDatabase.getShoppingList().size() == 0) {
					JOptionPane.showMessageDialog(null, "You have added no recipes to your shopping list.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				ShoppingListDialog shoppingListDialog = new ShoppingListDialog(recipeDatabase);
//				shoppingListDialog.setVisible(true);

			}
		});

		return menubar;
	}

	protected Properties configuration = new Properties();
	public static final String CONFIGURATION_FILENAME = "recipe.properties";
	public static final String DEFAULT_DATABASE_FILENAME = "recipe.db";

	/**
	 * saveConfigurationAndData
	 * saves configuration and data under the file
	 */
	protected void saveConfigurationAndData() {

		String dbFilename = this.configuration.getProperty("database.filename", DEFAULT_DATABASE_FILENAME);
		this.saveDataFile(dbFilename);
		this.configuration.setProperty("database.filename", dbFilename);
		try {
			this.configuration.store(new FileOutputStream(CONFIGURATION_FILENAME), "");
		} catch (IOException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "The file type cannot be used to save your data.", "Error",
					JOptionPane.ERROR_MESSAGE);
		}

	}

	/**
	 * loadConfigurationAndData
	 * loads configuration and data from a saved file
	 */
	protected void loadConfigurationAndData() {
		try {
			this.configuration.load(new FileInputStream(CONFIGURATION_FILENAME));
			String dbFilename = this.configuration.getProperty("database.filename", DEFAULT_DATABASE_FILENAME);
			try {
				this.loadDataFile(dbFilename);
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null,
						"The data file cannot be open or does not exist. A default one will be created on the exit of the application.",
						"Warning", JOptionPane.WARNING_MESSAGE);
			} catch (ClassNotFoundException | ClassCastException e) {
				JOptionPane.showMessageDialog(null,
						"The data file is corrupt and hence cannot be used. A new data file will be created on the exit of the application.",
						"Warning", JOptionPane.WARNING_MESSAGE);
			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,
					"The configuration file does not exist or is corrupt. The default value will be used.", "Warning",
					JOptionPane.WARNING_MESSAGE);
		}
	}

	/**
	 * main
	 * the entry point (main method) of the recipe program 
	 * @param args command-line argument. It is not used in the game.
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				TheRecipeProgram menu = new TheRecipeProgram();
				menu.setVisible(true);
			}
		});
	}
}
