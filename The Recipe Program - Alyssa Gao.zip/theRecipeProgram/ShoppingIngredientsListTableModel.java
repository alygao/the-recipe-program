package theRecipeProgram;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * ShoppingIngredientsListTableModel 
 * The table model that will display the list of ingredients needed for each recipe in the shopping list
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class ShoppingIngredientsListTableModel extends AbstractTableModel {

	/**
	 * the names of each column in the table
	 */
	private final String[] ingredientListColumnNames = { "Name", "Quantity", "Quantity Units", "Cost", "Bought" };
	
	/**
	 * the class type for each column
	 */
	private final Class[] columnClasses = { String.class, double.class, String.class, double.class, boolean.class };

	/**
	 * the list of shopping ingredients that are to be displayed within the table
	 */
	private List<ShoppingIngredient> ingredients = new ArrayList<>();

	@Override
	/**
	 * getColumnCount
	 * the number of columns in the table
	 * @return the number of columns
	 */
	public int getColumnCount() {
		return this.ingredientListColumnNames.length;
	}

	@Override
	/**
	 * getRowCount
	 * the number of rows in the table
	 * @return the number of rows
	 */
	public int getRowCount() {
		return ingredients.size();
	}

	@Override
	/**
	 * getColumnName
	 * @param col the column number
	 * @return the name of the column
	 */
	public String getColumnName(int col) {
		return this.ingredientListColumnNames[col];
	}

	@Override
	/**
	 * getValueAt
	 * finds the value at the specific row and column number
	 * @param row the row number
	 * @param col the column number
	 * @return the value at the specific row and column
	 */
	public Object getValueAt(int row, int col) {

		ShoppingIngredient shoppingIngredient = this.ingredients.get(row);
		switch (col) {
		case 0:
			return shoppingIngredient.getIngredient().getName();
		case 1:
			return shoppingIngredient.getIngredient().getQuantity();
		case 2:
			return shoppingIngredient.getIngredient().getQuantityUnits();
		case 3:
			return shoppingIngredient.getIngredient().getCost();
//		case 4:
		default:
			return shoppingIngredient.isBought();
		}
	}

	@Override
	/**
	 * getColumnClass
	 * finds the class type for a specific column
	 * @param col the column number
	 * @return the class type for the specific column
	 */
	public Class<?> getColumnClass(int col) {
		return this.columnClasses[col];
	}

	@Override
	/**
	 * isCellEditable
	 * checks if the user can edit the cell
	 * @param row the row number
	 * @param col the column number
	 * @return whether or not the cell is editable
	 */
	public boolean isCellEditable(int row, int col) {
		return false;
	}

	@Override
	/**
	 * setValueAt
	 * sets a value at the specific row and column
	 * @param value the value to be set
	 * @param row the row number
	 * @param col the column number
	 */
	public void setValueAt(Object value, int row, int col) {
		ShoppingIngredient shoppingIngredient = this.ingredients.get(row);
		switch (col) {
		case 0:
			shoppingIngredient.getIngredient().setName((String) value);
			break;
		case 1:
			shoppingIngredient.getIngredient().setQuantity((double) value);
			break;
		case 2:
			shoppingIngredient.getIngredient().setQuantityUnits((String) value);
			break;
		case 3:
			shoppingIngredient.getIngredient().setCost((double) value);
			break;
//		case 4:
		default:
			shoppingIngredient.setBought((boolean)value);
		}

		fireTableCellUpdated(row, col);
	}

	/**
	 * insertRow
	 * inserts a row in the table with an ingredient
	 * @param position the position to put the row 
	 * @param ingredient the ingredient to place in the table and add to the current list of ingredients
	 */
	public void insertRow(int position, ShoppingIngredient ingredient) {
		this.ingredients.add(ingredient);
		fireTableRowsInserted(0, getRowCount());
	}

	/**
	 * addRow
	 * adds a row at the bottom of the table with a new ingredient
	 * @param ingredient the ingredient to be placed in the table
	 */
	public void addRow(ShoppingIngredient ingredient) {
		insertRow(getRowCount(), ingredient);
	}

	/**
	 * addRows
	 * adds rows into the table
	 * @param ingredientList the list of ingredients that are to be put into the table
	 */
	public void addRows(List<ShoppingIngredient> ingredientList) {
		for (ShoppingIngredient ingredient : ingredientList) {
			addRow(ingredient);
		}
	}

	/**
	 * removeRow
	 * removes a specific row in the table
	 * @param position the position of the ingredient to be removed
	 */
	public void removeRow(int position) {
		this.ingredients.remove(position);
		fireTableRowsDeleted(0, getRowCount());
	}

	/**
	 * getData
	 * gets the list of ingredients
	 * @return the list of ingredients
	 */
	public List<ShoppingIngredient> getData() {
		return ingredients;
	}

	/**
	 * setData
	 * sets the list of ingredients
	 * @param data the list of ingredients
	 */
	public void setData(List<ShoppingIngredient> data) {
		this.ingredients = data;
		fireTableRowsInserted(0, getRowCount());
	}

	/**
	 * clearAll
	 * clears all rows in the table
	 */
	public void clearAll() {
		setData(new ArrayList<ShoppingIngredient>());
		fireTableDataChanged();
	}
	
	/**
	 * refresh
	 * refreshes a specific row
	 * @param row the number of the row to refresh
	 */
	public void refresh ( int row ) {
		refresh( row, row );
	}

	/**
	 * refresh
	 * refreshes a specific number of rows
	 * @param rowStart the first row to refresh
	 * @param rowEnd the last row to refresh
	 */
	public void refresh ( int rowStart, int rowEnd ) {
		fireTableRowsUpdated( rowStart, rowEnd );
	}

}
