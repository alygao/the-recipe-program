package theRecipeProgram;

import java.util.List;
import java.io.Serializable;
import javax.swing.Icon;

/**
 * Recipe 
 * A template of a recipe
 * This includes the characteristics of each recipe and the necessary methods to call them.
 * 
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class Recipe implements Serializable, Comparable<Recipe> {

	/**
	 * The name of the recipe
	 */
	private String recipeName;
	
	/**
	 * The preparation time needed to make the recipe
	 */
	private int prepTime;
	
	/**
	 * The cook time needed to make the recipe
	 */
	private int cookTime;
	
	/**
	 * The ingredients needed to make the recipe
	 */
	private List <Ingredient> ingredients;
	
	/**
	 * The instructions needed to make the recipe
	 */
	private String instructions;
	
	/**
	 * Indicates whether or not recipe is vegetarian
	 */
	private boolean vegetarian;
	
	/**
	 * Indicates whether or not recipe is a favourite
	 */
	private boolean favourite;
	
	/**
	 * What food category the recipe falls under
	 */
	private String foodCategory;
	
	/**
	 * The image of the recipe dish
	 */
	private Icon image;
	
	/**
	 * constructor that initializes the recipe's characteristics
	 * @param recipeName the name of the recipe
	 * @param prepTime the preparation time needed to make the recipe
	 * @param cookTime the cook time needed to make the recipe
	 * @param favourite indicates if recipe is a favourite
	 * @param vegetarian indicates if recipe is vegetarian
	 * @param instructions the instructions needed to make the recipe
	 * @param foodCategory the food category the recipe falls under
	 * @param ingredients the ingredients needed to make the recipe
	 * @param image the image of the recipe dish
	 */
	Recipe(String recipeName, int prepTime, int cookTime, boolean favourite, boolean vegetarian,
			String instructions, String foodCategory, List<Ingredient> ingredients, Icon image) {
		this.setRecipeName(recipeName);
		this.setPrepTime(prepTime);
		this.setCookTime(cookTime);
		this.setVegetarian(vegetarian);
		this.setFavourite(favourite);
		this.setIngredients(ingredients);
		this.setInstructions(instructions);
		this.setFoodCategory(foodCategory);
		this.setImage(image);
	}

	/**
	 * getImage
	 * gets the image of recipe
	 * @return the image of the recipe
	 */
	public Icon getImage() {
		return image;
	}

	/**
	 * setImage
	 * sets the image of recipe
	 * @param image the image of the recipe
	 */
	public void setImage(Icon image) {
		this.image = image;
	}

	/**
	 * getRecipeName
	 * gets the name of recipe
	 * @return the name of the recipe
	 */
	public String getRecipeName() {
		return recipeName;
	}

	/**
	 * setRecipeName
	 * sets the name of recipe
	 * @param recipeName the name of the recipe
	 */
	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	/**
	 * getPrepTime
	 * gets the preparation time of the recipe
	 * @return preparation time of the recipe
	 */
	public int getPrepTime() {
		return prepTime;
	}

	/**
	 * setPrepTime
	 * sets the preparation time of the recipe
	 * @param prepTime the preparation time of the recipe
	 */
	public void setPrepTime(int prepTime) {
		this.prepTime = prepTime;
	}

	/**
	 * getIngredients
	 * gets the recipe's ingredients
	 * @return the recipe's ingredients
	 */
	public List<Ingredient> getIngredients() {
		return ingredients;
	}

	/**
	 * setIngredients
	 * sets the recipe's ingredients
	 * @param ingredients the recipe's ingredients
	 */
	public void setIngredients(List<Ingredient> ingredients) {
		this.ingredients = ingredients;
	}

	/**
	 * getInstructions
	 * gets the recipe's instructions
	 * @return the recipe's instructions
	 */
	public String getInstructions() {
		return instructions;
	}

	/**
	 * setInstructions
	 * sets the recipe's instructions
	 * @param instructions the recipe's instructions
	 */
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}

	/**
	 * isVegetarian
	 * finds if recipe is vegetarian
	 * @return true if recipe is vegetarian
	 */
	public boolean isVegetarian() {
		return vegetarian;
	}

	/**
	 * setVegetarian
	 * sets the recipe as vegetarian or not vegetarian
	 * @param vegetarian indicates if recipe is vegetarian or not
	 */
	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}

	/**
	 * isFavourite
	 * finds if recipe is favourite
	 * @return true if recipe is a favourite
	 */
	public boolean isFavourite() {
		return favourite;
	}

	/**
	 * setFavourite
	 * sets the recipe as a favourite or not 
	 * @param favourite indicates if recipe is favourite or not
	 */
	public void setFavourite(boolean favourite) {
		this.favourite = favourite;
	}

	/**
	 * getCookTime
	 * gets the cook time of the recipe
	 * @return cook time of the recipe
	 */
	public int getCookTime() {
		return cookTime;
	}

	/**
	 * setCookTime
	 * sets the cook time of the recipe
	 * @param cookTime the cook time of the recipe
	 */
	public void setCookTime(int cookTime) {
		this.cookTime = cookTime;
	}

	/**
	 * getCookTime
	 * gets the recipe's food category
	 * @return the recipe's food category
	 */
	public String getFoodCategory() {
		return foodCategory;
	}

	/**
	 * setFoodCategory
	 * sets the recipe's food category
	 * @param foodCategory the recipe's food category
	 */
	public void setFoodCategory(String foodCategory) {
		this.foodCategory = foodCategory;
	}

	@Override
	/**
	 * compareTo
	 * compares the recipes' names to see which one comes first in alphabetical order
	 * @param theOtherRecipe the other recipe to be compared to
	 * @return a negative integer, zero, or a positive integer if recipe is before, equal to, or after the other recipe
	 */
	public int compareTo(Recipe theOtherRecipe) {
		if ( theOtherRecipe == null || theOtherRecipe.recipeName == null || this.recipeName == null ) {
			return -1;
		}
		return this.getRecipeName().compareToIgnoreCase(theOtherRecipe.recipeName);
	}
	
	@Override
	/**
	 * equals
	 * compares if recipes are equal to each other
	 * @param obj the other object being compared to
	 * @return true if equal
	 */
	public boolean equals(Object obj) {
		if ( obj == null ) {
			return false;
		} else if ( obj instanceof Recipe ) {
			Recipe theOtherRecipe = (Recipe) obj;
			if ( this.recipeName == null || theOtherRecipe.recipeName == null ) {
				return false;
			} else {
				return this.recipeName.equalsIgnoreCase ( theOtherRecipe.recipeName );
			}
		} else {
			return false;
		}
	}

	@Override
	/**
	 * Returns a string representation of the Recipe class.
	 * @return a string representation of the Recipe class.
	 */
	public String toString() {
		return "Recipe [recipeName=" + recipeName + ", prepTime=" + prepTime + ", cookTime=" + cookTime
				+ ", ingredients=" + ingredients + ", instructions=" + instructions + ", vegetarian=" + vegetarian
				+ ", favourite=" + favourite + ", foodCategory=" + foodCategory + ", image=" + image + "]";
	}

}
