package theRecipeProgram;

import java.io.Serializable;

/**
 * Ingredient 
 * A template of an ingredient that is necessary for each recipe
 * This includes the characteristics of each ingredient and the necessary methods to call them.
 * 
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class Ingredient implements Serializable{

	/**
	 * The name of the ingredient
	 */
	private String name;
	
	/**
	 * The quantity of the ingredient
	 */
	private double quantity;
	
	/**
	 * The units for the quantity (eg. cups, tbsp, etc.)
	 */
	private String quantityUnits;
	
	/**
	 * The cost of the ingredient
	 */
	private double cost;
	
	
	/**
	 * constructor that initializes the ingredient's name, quantity, quantity units and cost
	 * @param name the name of the ingredient
	 * @param quantity the quantity of the ingredient
	 * @param quantityUnits the units of the ingredient's quantity
	 * @param cost the cost of the ingredient
	 */
	Ingredient (String name, double quantity, String quantityUnits, double cost){
		this.setName(name);
		this.setQuantity(quantity);
		this.setQuantityUnits(quantityUnits);
		this.setCost(cost);
	}

	/**
	 * getName
	 * gets the ingredient's name
	 * @return the ingredient's name
	 */
	public String getName() {
		return name;
	}

	/**
	 * setName
	 * sets the ingredient's name
	 * @param name the ingredient's name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * getQuantity
	 * gets the ingredient's quantity
	 * @return the ingredient's quantity
	 */
	public double getQuantity() {
		return quantity;
	}

	/**
	 * setQuantity
	 * sets the ingredient's quantity
	 * @param quantity the ingredient's quantity
	 */
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	/**
	 * getQuantityUnits
	 * gets the ingredient's quantity units
	 * @return the ingredient's quantity units
	 */
	public String getQuantityUnits() {
		return quantityUnits;
	}

	/**
	 * setQuantityUnits
	 * sets the ingredient's quantity units
	 * @param quantityUnits the ingredient's quantity units
	 */
	public void setQuantityUnits(String quantityUnits) {
		this.quantityUnits = quantityUnits;
	}

	/**
	 * getCost
	 * gets the ingredient's cost
	 * @return the ingredient's cost
	 */
	public double getCost() {
		return cost;
	}

	/**
	 * setCost
	 * sets the ingredient's cost
	 * @param cost the ingredient's cost
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	@Override
	/**
	 * clone
	 * makes a copy of the ingredient
	 * @throws CloneNotSupportedException thrown if object does not implement Cloneable interface
	 * @return the clone of the ingredient
	 */
	public Ingredient clone() throws CloneNotSupportedException {
		return new Ingredient ( this.name, this.quantity, this.quantityUnits, this.cost );
	}

	@Override
	/**
	 * Returns a string representation of the Ingredient class.
	 * @return a string representation of the Ingredient class.
	 */
	public String toString() {
		return "Ingredient [name=" + name + ", quantity=" + quantity + ", quantityUnits=" + quantityUnits + ", cost="
				+ cost + "]";
	}
	
	
}
