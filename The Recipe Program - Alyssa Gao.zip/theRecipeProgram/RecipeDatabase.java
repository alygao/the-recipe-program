package theRecipeProgram;

import java.io.Serializable;

/**
 * RecipeDatabase 
 * Stores the recipe list and shopping list of recipes
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class RecipeDatabase implements Serializable {

	/**
	 * The list of recipes stored in a self-balancing binary tree
	 */
	private SelfBalancingBinaryTree<Recipe> recipeList = new SelfBalancingBinaryTree<>();
	
	/**
	 * The shopping list of recipes stored in a self-balancing binary tree
	 */
	private SelfBalancingBinaryTree<ShoppingRecipe> shoppingList = new SelfBalancingBinaryTree<>();

	
	/**
	 * getRecipeList
	 * gets the recipe list
	 * @return the recipe list
	 */
	public SelfBalancingBinaryTree<Recipe> getRecipeList() {
		return recipeList;
	}

	/**
	 * setRecipeList
	 * sets the recipe list
	 * @param recipeList the recipe list
	 */
	public void setRecipeList(SelfBalancingBinaryTree<Recipe> recipeList) {
		this.recipeList = recipeList;
	}

	/**
	 * getShoppingList
	 * gets the shopping list of recipes
	 * @return the shopping list of recipes
	 */
	public SelfBalancingBinaryTree<ShoppingRecipe> getShoppingList() {
		return shoppingList;
	}

	/**
	 * setShoppingList
	 * sets the shopping list of recipes
	 * @param shoppingList the shopping list of recipes
	 */
	public void setShoppingList(SelfBalancingBinaryTree<ShoppingRecipe> shoppingList) {
		this.shoppingList = shoppingList;
	}

}
