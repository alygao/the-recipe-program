package theRecipeProgram;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * ShoppingRecipe 
 * A template of a recipe in the shopping list
 * 
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class ShoppingRecipe implements Serializable, Comparable<ShoppingRecipe> {
	
	/**
	 * the original recipe
	 */
	private Recipe recipe;
	
	/**
	 * the recipe's ingredients now placed in the shopping list
	 */
	private List<ShoppingIngredient> ingredients;
	
	/**
	 * once all ingredients are bought, this will indicate that recipe is complete and ready to make
	 */
	private boolean complete = false;
	
	
	/**
	 * 1 of 2 constructors that initializes all variables
	 * @param recipe the recipe to be placed in shopping list
	 */
	public ShoppingRecipe( Recipe recipe ) {
		this ( recipe, false );
	}
	
	/**
	 * 2 of 2 constructors that initializes all variables
	 * @param recipe the recipe to be placed in shopping list
	 * @param complete indicates if recipe's ingredients are all bought
	 */
	public ShoppingRecipe( Recipe recipe, boolean complete ) {
		this.ingredients = new ArrayList<>();
		for ( Ingredient ingredient : recipe.getIngredients() ) {
			this.ingredients.add( new ShoppingIngredient ( ingredient ) );
		}
		this.recipe = new Recipe ( 
				recipe.getRecipeName(), 
				recipe.getPrepTime(), 
				recipe.getCookTime(),
				recipe.isFavourite(),
				recipe.isVegetarian(),
				recipe.getInstructions(),
				recipe.getFoodCategory(),
				null,
				recipe.getImage() );
		this.complete = complete;
	}

	/**
	 * isComplete
	 * finds if recipe is complete
	 * @return true if recipe is complete
	 */
	public boolean isComplete() {
		return complete;
	}

	/**
	 * setComplete
	 * sets the recipe as complete or not
	 * @param complete indicates if recipe is complete or not
	 */
	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	/**
	 * getRecipe
	 * gets the recipe
	 * @return the recipe
	 */
	public Recipe getRecipe() {
		return recipe;
	}

	/**
	 * setRecipe
	 * sets the recipe
	 * @param recipe the recipe to be contained in the ShoppingRecipe object.
	 */
	public void setRecipe(Recipe recipe) {
		this.recipe = recipe;
	}

	/**
	 * getIngredients
	 * gets the list of ingredients in the shopping list
	 * @return the ingredients in the shopping list
	 */
	public List<ShoppingIngredient> getIngredients() {
		return ingredients;
	}

	/**
	 * setIngredients
	 * sets the list of ingredients in the shopping list
	 * @param ingredients the ingredients in the shopping list
	 */
	public void setIngredients(List<ShoppingIngredient> ingredients) {
		this.ingredients = ingredients;
	}

	@Override
	/**
	 * compareTo
	 * compares the recipes' names to see which one comes first in alphabetical order
	 * @param theOtherShoppingRecipe the other recipe to be compared to
	 * @return a negative integer, zero, or a positive integer if recipe is before, equal to, or after the other recipe
	 */
	public int compareTo(ShoppingRecipe theOtherShoppingRecipe) {
		if ( theOtherShoppingRecipe == null || theOtherShoppingRecipe.recipe == null || this.recipe == null || theOtherShoppingRecipe.recipe.getRecipeName() == null || this.recipe.getRecipeName() == null ) {
			return -1;
		}
		return this.recipe.compareTo(theOtherShoppingRecipe.recipe);
	}
	
	@Override
	/**
	 * equals
	 * compares if recipes are equal to each other
	 * @param obj the other object being compared to
	 * @return true if equal
	 */
	public boolean equals(Object obj) {
		if ( obj == null ) {
			return false;
		} else if ( obj instanceof ShoppingRecipe ) {
			ShoppingRecipe theOtherShoppingRecipe = (ShoppingRecipe) obj;
			if ( this.recipe == null || theOtherShoppingRecipe.recipe == null ) {
				return false;
			} else {
				return this.recipe.equals ( theOtherShoppingRecipe.recipe );
			}
		} else {
			return false;
		}
	}

	@Override
	/**
	 * Returns a string representation of the ShoppingRecipe class.
	 * @return a string representation of the ShoppingRecipe class.
	 */
	public String toString() {
		return "ShoppingRecipe [recipe=" + recipe + ", ingredients=" + ingredients + ", complete=" + complete + "]";
	}
	
//	@Override
//	public int hashCode() {
//		return this.recipe == null ? 0 : this.recipe.hashCode();
//	}

	
	
}
