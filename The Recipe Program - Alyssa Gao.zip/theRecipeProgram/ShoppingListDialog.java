package theRecipeProgram;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * ShoppingListDialog 
 * The dialog that will show the shopping list
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class ShoppingListDialog extends JDialog {

	/**
	 * used to view the shopping list
	 */
	private RecipeDatabase recipeDatabase;
	
	/**
	 * reference this dialog as 'selfDialog'
	 */
	private JDialog selfDialog = this;

	/**
	 * Shopping List Table Model for shopping list of recipes
	 */
	private ShoppingListTableModel shoppingListTableModel;
	
	/**
	 * Table to store all recipes in shopping list
	 */
	private JTable shoppingListTable;
	
	/**
	 * Shopping Ingredients List Table Model for shopping list of ingredients per recipe
	 */
	private ShoppingIngredientsListTableModel shoppingIngredientsListTableModel;
	
	/**
	 * Table to store all ingredients in shopping list
	 */
	private JTable ingredientsShoppingListTable;

	/**
	 * Button to remove recipe from shopping list
	 */
	private JButton removeRecipeFromShoppingListButton;
	
	/**
	 * Button to view recipes (opens 'View Recipe' dialog)
	 */
	private JButton viewRecipesButton;
	
	/**
	 * In-editable text area to view instructions to use shopping list dialog
	 */
	private JTextArea instructionsToUseShoppingListTextArea;
	
	/**
	 * The background for the shopping list dialog
	 */
	private ImageIcon background = null;

	/**
	 * initial row number for the shopping list (user hasn't selected a recipe)
	 */
	private int selectedShoppingRecipeRow = -1;

	/**
	 * The panel to display all GUI
	 */
	private JPanel panel;

	/**
	 * initializes user interface and recipe recipe database
	 * @param recipeDatabase the RecipeDatabase object to be associated with the ShoppingListDialog.
	 */
	public ShoppingListDialog(RecipeDatabase recipeDatabase) {
		this.recipeDatabase = recipeDatabase;
		initUI();
	}
	
	/**
	 * initUI 
	 * Initializes the panel's attributes and loads the background image
	 */
	private void initUI() {

		setModalityType(ModalityType.APPLICATION_MODAL);

		setDefaultLookAndFeelDecorated(true);
		setTitle("Shopping List");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		panel = new JPanel();
		panel.setLayout(null);
		getContentPane().add(panel);
		
		background = new ImageIcon(getClass().getResource("pink background 2.JPG"));
		JLabel backgroundLabel = new JLabel ();
		backgroundLabel.setIcon(background);
		backgroundLabel.setBounds(0, 0, 1000, 600);

		shoppingListTableModel = new ShoppingListTableModel();
		shoppingListTable = new JTable(shoppingListTableModel);
		shoppingListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		shoppingListTable.setBounds(25, 50, 300, 400);

		shoppingListTableModel.addRows(recipeDatabase.getShoppingList());

		JScrollPane shoppingListScrollPane = new JScrollPane(shoppingListTable);
		shoppingListScrollPane.setBounds(25, 50, 300, 400);
		panel.add(shoppingListScrollPane);

		shoppingListTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			/**
			 * valueChanged 
			 * Called when the value of selection changes
			 * @param e the event that characterizes the change
			 */
			public void valueChanged(ListSelectionEvent e) {
				if (e.getValueIsAdjusting())
					return;

				ListSelectionModel lsm = (ListSelectionModel) e.getSource();

				if (!lsm.isSelectionEmpty()) {
					selectedShoppingRecipeRow = lsm.getMinSelectionIndex();
					ShoppingRecipe selectedRecipe = shoppingListTableModel.getData().get(selectedShoppingRecipeRow);
					displayShoppingListIngredients(selectedRecipe);
				}
			}

		});

		instructionsToUseShoppingListTextArea = new JTextArea(
				"Select a recipe from the shopping list to view ingredients. Once an ingredient is bought, simply double click the ingredient in the ingredient list table and that will mark it as bought. To mark the ingredient as 'not bought', simply double click the ingredient again. Once all ingredients are marked bought, then the recipe in the shopping list table will be marked as complete and ready to make.");
		instructionsToUseShoppingListTextArea.setEditable(false);
		instructionsToUseShoppingListTextArea.setLineWrap(true);
		instructionsToUseShoppingListTextArea.setWrapStyleWord(true);
		instructionsToUseShoppingListTextArea.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
		instructionsToUseShoppingListTextArea.setBounds(725, 200, 200, 200);
		instructionsToUseShoppingListTextArea.setOpaque(false);
		panel.add(instructionsToUseShoppingListTextArea);

		viewRecipesButton = new JButton ("View Recipes");
		viewRecipesButton.setBounds(725, 450, 200, 30);
		panel.add(viewRecipesButton);
		viewRecipesButton.addActionListener(new ActionListener() {
			@Override
			/**
			 * actionPerformed 
			 * Invoked when an action occurs
			 * @param e the action that occurs
			 */
			public void actionPerformed(ActionEvent e) {
				dispose();
				ViewRecipeDialog viewRecipeDialog = new ViewRecipeDialog(recipeDatabase);
//				viewRecipeDialog.setVisible(true);
			}
		});
		
		removeRecipeFromShoppingListButton = new JButton("Remove From Shopping List");
		removeRecipeFromShoppingListButton.setBounds(725, 500, 200, 30);
		panel.add(removeRecipeFromShoppingListButton);
		removeRecipeFromShoppingListButton.addActionListener(new ActionListener() {
			
			@Override
			/**
			 * actionPerformed 
			 * Invoked when an action occurs
			 * @param e the action that occurs
			 */
			public void actionPerformed(ActionEvent e) {
				int selectedRow = shoppingListTable.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(selfDialog, "Please choose a recipe to remove from shopping list.",
							"Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				shoppingListTableModel.removeRow(selectedRow);
				shoppingIngredientsListTableModel.clearAll();
				recipeDatabase.getShoppingList().remove(selectedRow);

			}
		});
		panel.add (backgroundLabel);
		setVisible(true);

	}

	/**
	 * displayShoppingListIngredients 
	 * Displays the ingredients from the selected recipe in the shopping list table
	 * @param selectedRecipe the recipe in which its ingredients are to be displayed
	 */
	private void displayShoppingListIngredients(ShoppingRecipe selectedRecipe) {
		// ==== INGREDIENTS SHOPPING LIST ====
		shoppingIngredientsListTableModel = new ShoppingIngredientsListTableModel();
		ingredientsShoppingListTable = new JTable(shoppingIngredientsListTableModel);
		ingredientsShoppingListTable.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		ingredientsShoppingListTable.setBounds(350, 50, 300, 400);

		shoppingIngredientsListTableModel.addRows(selectedRecipe.getIngredients());

		JScrollPane ingredientsShoppingListScrollPane = new JScrollPane(ingredientsShoppingListTable);
		ingredientsShoppingListScrollPane.setBounds(350, 50, 300, 400);
		panel.add(ingredientsShoppingListScrollPane);

		ingredientsShoppingListTable.addMouseListener(new MouseAdapter() {
			
			/**
			 * mousePressed 
			 * based on the number of clicks on the selected row, it will change the ingredient to either bought or not bought
			 * @param mouseEvent the action occurring from the mouse (eg. the number of clicks)
			 */
			public void mousePressed(MouseEvent mouseEvent) {
				JTable table = (JTable) mouseEvent.getSource();
				Point point = mouseEvent.getPoint();
				int row = table.rowAtPoint(point);
				if ((mouseEvent.getClickCount()) == 2 && (table.getSelectedRow() != -1)) {
					ShoppingIngredient selectedShoppingIngredient = shoppingIngredientsListTableModel.getData()
							.get(row);
					selectedShoppingIngredient.setBought(!selectedShoppingIngredient.isBought());
					shoppingIngredientsListTableModel.refresh(row);
					checkAndUpdateShoppingRecipeCompleteStatus();
				}
			}
		});

	}

	/**
	 * checkAndUpdateShoppingRecipeCompleteStatus 
	 * checks if all ingredients have been bought and changes the status of the recipe to complete/incomplete
	 */
	private void checkAndUpdateShoppingRecipeCompleteStatus() {
		if ((this.selectedShoppingRecipeRow >= 0)
				&& (this.selectedShoppingRecipeRow < this.recipeDatabase.getShoppingList().size())) {
			ShoppingRecipe selectedShoppingRecipe = this.recipeDatabase.getShoppingList()
					.get(this.selectedShoppingRecipeRow);
			boolean allIngredientsComplete = true;
			for (ShoppingIngredient shoppingIngredient : selectedShoppingRecipe.getIngredients()) {
				allIngredientsComplete &= shoppingIngredient.isBought();
			}
			selectedShoppingRecipe.setComplete(allIngredientsComplete);
			shoppingListTableModel.refresh(this.selectedShoppingRecipeRow);
		}
	}
}
