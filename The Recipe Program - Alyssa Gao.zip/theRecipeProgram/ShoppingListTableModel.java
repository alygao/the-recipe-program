package theRecipeProgram;

import javax.swing.table.AbstractTableModel;

/**
 * ShoppingListTableModel 
 * The table model that will display the recipes in the shopping list
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class ShoppingListTableModel extends AbstractTableModel {
	
	/**
	 * the names of each column in the table
	 */
	private final String[] recipeListColumnNames = { "Name", "Prep Time (min.)", "Favourite", "Vegetarian", "Complete" };
	
	/**
	 * the class type for each column
	 */
	private final Class[] columnClasses = { String.class, double.class, boolean.class, boolean.class, boolean.class };

	/**
	 * the list of recipes (shopping list) that are to be displayed within the table
	 */
	private SelfBalancingBinaryTree<ShoppingRecipe> data = new SelfBalancingBinaryTree<>();

	@Override
	/**
	 * getColumnCount
	 * the number of columns in the table
	 * @return the number of columns
	 */
	public int getColumnCount() {
		return this.recipeListColumnNames.length;
	}

	@Override
	/**
	 * getRowCount
	 * the number of rows in the table
	 * @return the number of rows
	 */
	public int getRowCount() {
		return data.size();
	}

	@Override
	/**
	 * getColumnName
	 * @param col the column number
	 * @return the name of the column
	 */
	public String getColumnName(int col) {
		return this.recipeListColumnNames[col];
	}

	@Override
	/**
	 * getValueAt
	 * finds the value at the specific row and column number
	 * @param row the row number
	 * @param col the column number
	 * @return the value at the specific row and column
	 */
	public Object getValueAt(int row, int col) {

		ShoppingRecipe shoppingRecipe = this.data.get(row);
		switch (col) {
		case 0:
			return shoppingRecipe.getRecipe().getRecipeName();
		case 1:
			return shoppingRecipe.getRecipe().getPrepTime();
		case 2:
			return shoppingRecipe.getRecipe().isFavourite();
		case 3:
			return shoppingRecipe.getRecipe().isVegetarian();
//		case 4:
		default:
			return shoppingRecipe.isComplete();
		}
	}

	@Override
	/**
	 * getColumnClass
	 * finds the class type for a specific column
	 * @param col the column number
	 * @return the class type for the specific column
	 */
	public Class<?> getColumnClass(int col) {
		return this.columnClasses[col];
	}

	@Override
	/**
	 * isCellEditable
	 * checks if the user can edit the cell
	 * @param row the row number
	 * @param col the column number
	 * @return whether or not the cell is editable
	 */
	public boolean isCellEditable(int row, int col) {
		return false;
	}

	@Override
	/**
	 * setValueAt
	 * sets a value at the specific row and column
	 * @param value the value to be set
	 * @param row the row number
	 * @param col the column number
	 */
	public void setValueAt(Object value, int row, int col) {
		ShoppingRecipe shoppingRecipe = this.data.get(row);
		switch (col) {
		case 0:
			shoppingRecipe.getRecipe().setRecipeName((String) value);
			break;
		case 1:
			shoppingRecipe.getRecipe().setPrepTime((int) value);
			break;
		case 2:
			shoppingRecipe.getRecipe().setFavourite((boolean)value);
			break;
		case 3:
			shoppingRecipe.getRecipe().setVegetarian((boolean) value);
			break;
//		case 4:
		default:
			shoppingRecipe.setComplete((boolean) value);
		}

		fireTableCellUpdated(row, col);
	}
	
	/**
	 * updateRow
	 * when an recipe is modified, the row must be then updated
	 * @param recipe the recipe to place in the table and add to the current list of shopping list recipes
	 * @param row the row that needs to be updated due to a change in the recipe
	 */
	public void updateRow ( ShoppingRecipe recipe, int row ) {
		this.data.set( row, recipe );
		fireTableRowsUpdated( row, row );
	}

	/**
	 * insertRow
	 * inserts a row in the table with a recipe
	 * @param position the position to put the row 
	 * @param recipe the recipe to place in the table and add to the shopping list
	 */
	public void insertRow(int position, ShoppingRecipe recipe) {
		this.data.add(recipe);
		fireTableRowsInserted(0, getRowCount());
	}

	/**
	 * addRow
	 * adds a row at the bottom of the table with a new recipe
	 * @param recipe the recipe to be placed in the table
	 */
	public void addRow(ShoppingRecipe recipe) {
		insertRow(getRowCount(), recipe);
	}

	/**
	 * addRows
	 * adds rows into the table
	 * @param recipeList the list of recipes that are to be put into the table
	 */
	public void addRows(SelfBalancingBinaryTree<ShoppingRecipe> recipeList) {
		for (ShoppingRecipe recipe : recipeList) {
			addRow(recipe);
		}
	}

	/**
	 * removeRow
	 * removes a specific row in the table
	 * @param position the position of the recipe to be removed
	 */
	public void removeRow(int position) {
		this.data.remove(position);
		fireTableRowsDeleted(0, getRowCount());
	}

	/**
	 * getData
	 * gets the list of recipes
	 * @return the list of shopping list recipes
	 */
	public SelfBalancingBinaryTree<ShoppingRecipe> getData() {
		return data;
	}

	/**
	 * setData
	 * sets the list of recipes
	 * @param data the list of shopping list recipes
	 */
	public void setData(SelfBalancingBinaryTree<ShoppingRecipe> data) {
		this.data = data;
		fireTableRowsInserted(0, getRowCount());
	}

	/**
	 * clearAll
	 * clears all rows in the table
	 */
	public void clearAll() {
		setData(new SelfBalancingBinaryTree<ShoppingRecipe>());
		fireTableDataChanged();
	}
	
	/**
	 * refresh
	 * refreshes a specific row
	 * @param row the number of the row to refresh.
	 */
	public void refresh(int row) {
		fireTableRowsUpdated(row, row);
	}

	/**
	 * refresh
	 * refreshes a specific number of rows
	 * @param rowStart the first row to refresh
	 * @param rowEnd the last row to refresh
	 */
	public void refresh(int rowStart, int rowEnd) {
		fireTableRowsUpdated(rowStart, rowEnd);
	}
	
}
