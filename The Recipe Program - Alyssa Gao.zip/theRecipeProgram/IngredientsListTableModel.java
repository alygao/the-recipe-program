package theRecipeProgram;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * IngredientsListTableModel 
 * The table model that will display the list of ingredients
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class IngredientsListTableModel extends AbstractTableModel {

	/**
	 * the names of each column in the table
	 */
	private final String[] ingredientListColumnNames = { "Name", "Quantity", "Quantity Units", "Cost" };
	
	/**
	 * the class type for each column
	 */
	private final Class[] columnClasses = { String.class, double.class, String.class, double.class };

	/**
	 * the list of ingredients that are to be displayed within the table
	 */
	private List<Ingredient> ingredients = new ArrayList<>();

	@Override
	/**
	 * getColumnCount
	 * the number of columns in the table
	 * @return the number of columns
	 */
	public int getColumnCount() {
		return this.ingredientListColumnNames.length;
	}

	@Override
	/**
	 * getRowCount
	 * the number of rows in the table
	 * @return the number of rows
	 */
	public int getRowCount() {

		return ingredients.size();
	}

	@Override
	/**
	 * getColumnName
	 * @param col the column number
	 * @return the name of the column
	 */
	public String getColumnName(int col) {
		return this.ingredientListColumnNames[col];
	}

	@Override
	/**
	 * getValueAt
	 * finds the value at the specific row and column number
	 * @param row the row number
	 * @param col the column number
	 * @return the value at the specific row and column
	 */
	public Object getValueAt(int row, int col) {

		Ingredient ingredient = this.ingredients.get(row);
		switch (col) {
		case 0:
			return ingredient.getName();
		case 1:
			return ingredient.getQuantity();
		case 2:
			return ingredient.getQuantityUnits();
		// case 3:
		default:
			return ingredient.getCost();
		}
	}

	@Override
	/**
	 * getColumnClass
	 * finds the class type for a specific column
	 * @param col the column number
	 * @return the class type for the specific column
	 */
	public Class<?> getColumnClass(int col) {
		return this.columnClasses[col];
	}

	@Override
	/**
	 * isCellEditable
	 * checks if the user can edit the cell
	 * @param row the row number
	 * @param col the column number
	 * @return whether or not the cell is editable
	 */
	public boolean isCellEditable(int row, int col) {
		return false;
	}

	@Override
	/**
	 * setValueAt
	 * sets a value at the specific row and column
	 * @param value the value to be set
	 * @param row the row number
	 * @param col the column number
	 */
	public void setValueAt(Object value, int row, int col) {
		Ingredient ingredient = this.ingredients.get(row);
		switch (col) {
		case 0:
			ingredient.setName((String) value);
			break;
		case 1:
			ingredient.setQuantity((double) value);
			break;
		case 2:
			ingredient.setQuantityUnits((String) value);
			break;
		// case 3:
		default:
			ingredient.setCost((double) value);
		}

		fireTableCellUpdated(row, col);
	}

	/**
	 * insertRow
	 * inserts a row in the table with an ingredient
	 * @param position the position to put the row 
	 * @param ingredient the ingredient to place in the table and add to the current list of ingredients
	 */
	public void insertRow(int position, Ingredient ingredient) {
		this.ingredients.add(ingredient);
		fireTableRowsInserted(0, getRowCount());
	}

	/**
	 * addRow
	 * adds a row at the bottom of the table with a new ingredient
	 * @param ingredient the ingredient to be placed in the table
	 */
	public void addRow(Ingredient ingredient) {
		insertRow(getRowCount(), ingredient);
	}

	/**
	 * addRows
	 * adds rows into the table
	 * @param ingredientList the list of ingredients that are to be put into the table
	 */
	public void addRows(List<Ingredient> ingredientList) {
		for (Ingredient ingredient : ingredientList) {
			addRow(ingredient);
		}
	}

	/**
	 * removeRow
	 * removes a specific row in the table
	 * @param position the position of the ingredient to be removed
	 */
	public void removeRow(int position) {
		this.ingredients.remove(position);
		fireTableRowsDeleted(0, getRowCount());
	}

	/**
	 * getData
	 * gets the list of ingredients
	 * @return the list of ingredients
	 */
	public List<Ingredient> getData() {
		return ingredients;
	}

	/**
	 * setData
	 * sets the list of ingredients
	 * @param data the list of ingredients
	 */
	public void setData(List<Ingredient> data) {
		this.ingredients = data;
		fireTableRowsInserted(0, getRowCount());
	}
	
	/**
	 * clearAll
	 * clears all rows in the table
	 */
	public void clearAll() {
		setData(new ArrayList<Ingredient>());
		fireTableDataChanged();
	}

}
