package theRecipeProgram;

import java.io.Serializable;

/**
 * Ingredient 
 * A template of an ingredient that is necessary for each recipe in the shopping list
 * This includes the characteristics of each ingredient and the necessary methods to call them.
 * 
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class ShoppingIngredient implements Serializable {
	
	/**
	 * the original ingredient
	 */
	private Ingredient ingredient;
	
	/**
	 * indicates if ingredient has been bought 
	 */
	private boolean bought;
	
	/**
	 * 1 of 2 constructors that initializes all variables
	 * @param ingredient the ingredient to be placed in shopping list
	 */
	ShoppingIngredient ( Ingredient ingredient ) {
		this ( ingredient, false );
	}

	/**
	 * 2 of 2 constructors that initializes all variables
	 * @param ingredient the ingredient to be placed in shopping list
	 * @param bought indicates if ingredient is bought
	 */
	ShoppingIngredient ( Ingredient ingredient, boolean bought ) {
		try {
			this.ingredient = ingredient.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		this.bought = bought;
	}

	/**
	 * getIngredient
	 * gets the ingredient
	 * @return the ingredient
	 */
	public Ingredient getIngredient() {
		return ingredient;
	}

	/**
	 * setIngredient
	 * sets the ingredient
	 * @param ingredient the ingredient to be set
	 */
	public void setIngredient(Ingredient ingredient) {
		this.ingredient = ingredient;
	}

	/**
	 * isBought
	 * finds if ingredient is bought
	 * @return true if recipe is bought
	 */
	public boolean isBought() {
		return bought;
	}

	/**
	 * setBought
	 * sets the ingredient as bought or not
	 * @param bought indicates if recipe is bought or not
	 */
	public void setBought(boolean bought) {
		this.bought = bought;
	}

	@Override
	/**
	 * Returns a string representation of the ShoppingIngredient class.
	 * @return a string representation of the ShoppingIngredient class.
	 */
	public String toString() {
		return "ShoppingIngredient [ingredient=" + ingredient + ", bought=" + bought + "]";
	}
	
	
	
}
