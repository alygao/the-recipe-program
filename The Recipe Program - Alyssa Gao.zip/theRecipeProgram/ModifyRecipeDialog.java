package theRecipeProgram;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.Border;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.NumberFormatter;

/**
 * ModifyRecipeDialog 
 * The dialog that will open when modifying a recipe
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */
public class ModifyRecipeDialog extends JDialog {
	
	/**
	 * The panel to display all GUI
	 */
	private JPanel panel;

	/**
	 * reference this dialog as 'selfDialog'
	 */
	private JDialog selfDialog = this;

	/**
	 * The field for user to type the recipe name
	 */
	private JTextField recipeNameField;
	
	/**
	 * The field for user to type the preparation time
	 */
	private JFormattedTextField prepTimeField;
	
	/**
	 * The field for user to type the cook time
	 */
	private JFormattedTextField cookTimeField;
	
	/**
	 * The field for user to type the instructions
	 */
	private JTextArea instructionsField;
	
	/**
	 * The check box for user to check off if recipe is a favourite
	 */
	private JCheckBox isFavouriteCheckBox;
	
	/**
	 * The check box for user to check off if recipe is vegetarian
	 */
	private JCheckBox isVegetarianCheckBox;
	
	/**
	 * The combo box for user to choose a food category
	 */
	private JComboBox foodCategoryField;
	
	/**
	 * The button to save recipe
	 */
	private JButton saveRecipeButton;
	
	/**
	 * The button to load an image
	 */
	private JButton loadImageButton;
	
	/**
	 * The label to display the 'Recipe Image' header
	 */
	private JLabel recipeImageJLabel;

	/**
	 * The button to add an ingredient
	 */
	private JButton addIngredientButton;
	
	/**
	 * The button to delete an ingredient
	 */
	private JButton deleteIngredientButton;
	
	/**
	 * The table to display all ingredients
	 */
	private JTable ingredientsListTable;
	
	/**
	 * The table model for the ingredient list table
	 */
	private IngredientsListTableModel ingredientsListTableModel;
	
	/**
	 * The text field to write the ingredient name
	 */
	private JTextField ingredientNameField;
	
	/**
	 * The text field to write the ingredient quantity
	 */
	private JFormattedTextField ingredientQuantityField;
	
	/**
	 * The text field to write the ingredient quantity units (eg. cups, tbsp, etc.)
	 */
	private JTextField ingredientQuantityUnitsField;
	
	/**
	 * The text field to write the cost
	 */
	private JFormattedTextField costField;
	
	/**
	 * The background for the modify recipe dialog
	 */
	private ImageIcon background = null;

	/**
	 * save the ingredients in an array list
	 */
	private List<Ingredient> ingredients = new ArrayList<>();
	
	/**
	 * once recipe is saved, it will be added to the recipeDatabase
	 */
	private RecipeDatabase recipeDatabase;
	
	/**
	 * once recipe is added, it will be saved in the recipe list which will then be viewed in the 'View Recipe' Dialog
	 */
	private RecipeListTableModel recipeListTableModel;
	
	/**
	 * the index to reference recipe in recipe list
	 */
	private int index;
	
	/**
	 * the recipe that is being modified
	 */
	private Recipe recipe;

	/**
	 * the constructor to initialize recipe database, recipe list table model, index, recipe and ingredients
	 * @param recipeDatabase stores the recipes in a binary tree and allows user to modify a recipe in the tree
	 * @param recipeListTableModel the table model in displaying the recipes (will be updated once recipe is saved)
	 * @param index the reference to the specific recipe being modified
	 */
	public ModifyRecipeDialog(RecipeDatabase recipeDatabase, RecipeListTableModel recipeListTableModel, int index) {
		this.recipeDatabase = recipeDatabase;
		this.index = index;
//		this.recipe = recipeDatabase.getRecipeList().get(index);
		this.recipe = recipeListTableModel.getData().get(index);
		this.recipeListTableModel = recipeListTableModel;
		this.ingredients = new ArrayList(recipe.getIngredients());
		initUI();
	}

	/**
	 * initUI 
	 * Initializes the panel's attributes and loads the background image
	 */
	private void initUI() {

		setModalityType(ModalityType.APPLICATION_MODAL);

		setDefaultLookAndFeelDecorated(true);
		setTitle("Edit Recipe");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		panel = new JPanel();
		panel.setLayout(null);
		getContentPane().add(panel);
		
		background = new ImageIcon(getClass().getResource("pink background 1.JPG"));
		JLabel backgroundLabel = new JLabel ();
		backgroundLabel.setIcon(background);
		backgroundLabel.setBounds(0, 0, 1000, 600);
		
		// ---------------------- Recipe Entry Box -------------------------

		// Formatter to ensure user does not enter non-numerical values
		DecimalFormat decimalFormat = new DecimalFormat("#0.00");
		NumberFormatter numFormatter = new NumberFormatter(decimalFormat);
		numFormatter.setAllowsInvalid(false); // specifies that invalid characters are not allowed

		// Initializes class variables as well as other labels used in the GUI
		JLabel recipeNameLabel = new JLabel("Recipe Name:");
		recipeNameLabel.setBounds(25, 50, 300, 30);
		this.recipeNameField = new JTextField(recipe.getRecipeName());
		this.recipeNameField.setBounds(125, 50, 300, 30);
		this.recipeNameField.setEditable( false );
		JLabel prepTimeLabel = new JLabel("Prep Time:");
		prepTimeLabel.setBounds(25, 100, 300, 30);
		this.prepTimeField = new JFormattedTextField(numFormatter);
		this.prepTimeField.setValue(recipe.getPrepTime());
		this.prepTimeField.setBounds(125, 100, 50, 30);
		JLabel prepTimeMinLabel = new JLabel("minutes");
		prepTimeMinLabel.setBounds(190, 100, 300, 30);
		JLabel cookTimeLabel = new JLabel("Cook Time:");
		cookTimeLabel.setBounds(25, 150, 300, 30);
		this.cookTimeField = new JFormattedTextField(numFormatter);
		this.cookTimeField.setValue(recipe.getCookTime());
		this.cookTimeField.setBounds(125, 150, 50, 30);
		JLabel cookTimeMinLabel = new JLabel("minutes");
		cookTimeMinLabel.setBounds(190, 150, 300, 30);
		JLabel instructionsLabel = new JLabel("Instructions");
		instructionsLabel.setBounds(25, 200, 300, 30);
		JScrollPane instructionsScrollPane = new JScrollPane();
		instructionsField = new JTextArea(recipe.getInstructions());
		instructionsField.setBounds(125, 200, 300, 100);
		instructionsField.setLineWrap(true);
		instructionsField.setWrapStyleWord(true);
		instructionsField.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
		

		isFavouriteCheckBox = new JCheckBox("Favourite", recipe.isFavourite());
		isFavouriteCheckBox.setBounds(25, 325, 100, 30);
		isVegetarianCheckBox = new JCheckBox("Vegetarian", recipe.isVegetarian());
		isVegetarianCheckBox.setBounds(150, 325, 100, 30);
		JLabel foodCategoryLabel = new JLabel("Food Category:");
		foodCategoryLabel.setBounds(25, 375, 300, 30);
		String[] foodCategoryOptions = { "Appetizers", "Beverages", "Soups/Salads", "Main Dishes", "Desserts" };
		foodCategoryField = new JComboBox(foodCategoryOptions);
		foodCategoryField.setBounds(125, 375, 150, 30);
		foodCategoryField.setSelectedItem(recipe.getFoodCategory());

		recipeImageJLabel = new JLabel(recipe.getImage());
		recipeImageJLabel.setBounds(800, 100, 150, 150);
		Border recipeImageJLabeborder = BorderFactory.createLineBorder(Color.BLACK, 1);
		recipeImageJLabel.setBorder(recipeImageJLabeborder);
		panel.add(recipeImageJLabel);

		loadImageButton = new JButton("Load Image");
		loadImageButton.setBounds(850, 60, 100, 30);
		loadImageButton.addActionListener(new ButtonListener());
		panel.add(loadImageButton);

		panel.add(recipeNameLabel);
		panel.add(recipeNameField);
		panel.add(prepTimeLabel);
		panel.add(prepTimeField);
		panel.add(prepTimeMinLabel);
		panel.add(cookTimeLabel);
		panel.add(cookTimeField);
		panel.add(cookTimeMinLabel);
		panel.add(instructionsLabel);
		panel.add(instructionsField);
		panel.add(isFavouriteCheckBox);
		panel.add(isVegetarianCheckBox);
		panel.add(foodCategoryLabel);
		panel.add(foodCategoryField);

		saveRecipeButton = new JButton("Save Recipe to Database");
		saveRecipeButton.setBounds(400, 525, 200, 30);
		saveRecipeButton.addActionListener(new ButtonListener());
		panel.add(saveRecipeButton);

		// ------------------- Ingredient list table (JTable)
		// ----------------------------

		ingredientsListTableModel = new IngredientsListTableModel();
		ingredientsListTable = new JTable(ingredientsListTableModel);
		ingredientsListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ingredientsListTable.setBounds(450, 100, 300, 175);

		JScrollPane ingredientListScrollPane = new JScrollPane(ingredientsListTable);
		ingredientListScrollPane.setBounds(450, 100, 300, 175);
		panel.add(ingredientListScrollPane);
		
		ingredientsListTableModel.addRows(recipe.getIngredients());
		
		// ---------------------- components for displaying selected ingredient
				// ----------------------

		JLabel ingredientHeaderLabel = new JLabel("Ingredient List: ");
		ingredientHeaderLabel.setBounds(450, 50, 300, 30);
		JLabel ingredientNameLabel = new JLabel("Ingredient Name:");
		ingredientNameLabel.setBounds(450, 300, 300, 30);
		this.ingredientNameField = new JTextField();
		this.ingredientNameField.setBounds(560, 300, 190, 30);
		JLabel quantityLabel = new JLabel("Quantity:");
		quantityLabel.setBounds(450, 340, 200, 30);
		this.ingredientQuantityField = new JFormattedTextField(numFormatter);
		this.ingredientQuantityField.setBounds(510, 340, 50, 30);
		JLabel quantityUnitsLabel = new JLabel("Quantity Units:");
		quantityUnitsLabel.setBounds(600, 340, 200, 30);
		this.ingredientQuantityUnitsField = new JTextField();
		this.ingredientQuantityUnitsField.setBounds(690, 340, 60, 30);
		JLabel costLabel = new JLabel("Cost:");
		costLabel.setBounds(450, 380, 300, 30);
		this.costField = new JFormattedTextField(numFormatter);
		this.costField.setBounds(500, 380, 75, 30);

		panel.add(ingredientHeaderLabel);
		panel.add(ingredientNameLabel);
		panel.add(ingredientNameField);
		panel.add(quantityLabel);
		panel.add(ingredientQuantityField);
		panel.add(quantityUnitsLabel);
		panel.add(ingredientQuantityUnitsField);
		panel.add(costLabel);
		panel.add(costField);

		addIngredientButton = new JButton("Add Ingredient");
		addIngredientButton.setBounds(450, 425, 150, 30);
		addIngredientButton.addActionListener(new ButtonListener());
		panel.add(addIngredientButton);

		deleteIngredientButton = new JButton("Delete Ingredient");
		deleteIngredientButton.setBounds(625, 425, 150, 30);
		panel.add(deleteIngredientButton);
		deleteIngredientButton.addActionListener(new ButtonListener());
		
		instructionsScrollPane.getViewport().add(this.instructionsField);
		instructionsScrollPane.setBounds(125, 200, 300, 100);
		panel.add(instructionsScrollPane);
		
		panel.add (backgroundLabel);
		
		setVisible(true);

	}

	/**
	 * ButtonListener 
	 * inner class that checks which button was pressed and executes the corresponding action
	 * @author Alyssa Gao
	 * @version 1.0
	 * @since May 5, 2019
	 */
	class ButtonListener implements ActionListener {

		/**
		 * actionPerformed 
		 * performs the action that is needed to be performed from clicking a button
		 * @param press used to determine which button is pressed
		 */
		public void actionPerformed(ActionEvent press) {
			if (press.getSource() == saveRecipeButton) {
				
				for (int i = 0; i < recipeDatabase.getRecipeList().size() && i != index; i++) {
					if ((recipeDatabase.getRecipeList().get(i).getRecipeName().toLowerCase())
							.equals((recipeNameField.getText().toLowerCase()))) {
						JOptionPane.showMessageDialog(selfDialog, "You already have added a recipe with the same name.",
								"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}
				
				if ((recipeNameField.getText().equals("")) || (prepTimeField.getText().equals(""))
						|| (cookTimeField.getText().equals("")) || (instructionsField.getText().equals(""))) {
					JOptionPane.showMessageDialog(selfDialog, "You are still missing values in your recipe.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if (ingredients.size() == 0) {
					JOptionPane.showMessageDialog(selfDialog, "You have no ingredients in your recipe", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				Recipe newRecipe = new Recipe(recipeNameField.getText().toUpperCase(), (int) Double.parseDouble(prepTimeField.getText()),
						(int) Double.parseDouble(cookTimeField.getText()), isFavouriteCheckBox.isSelected(),
						isVegetarianCheckBox.isSelected(), instructionsField.getText(),
						foodCategoryField.getSelectedItem().toString(), ingredients, recipeImageJLabel.getIcon());
				recipeDatabase.getRecipeList().set(index, newRecipe);
				recipeListTableModel.updateRow(newRecipe, index);
				dispose();
			} else if (press.getSource() == loadImageButton) {
				JFileChooser fileopen = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter("Image files", ".jpg");
				fileopen.addChoosableFileFilter(filter);

				int ret = fileopen.showDialog(panel, "Open file");
				if (ret == JFileChooser.APPROVE_OPTION) {
					File file = fileopen.getSelectedFile();
					try {
						BufferedImage img = ImageIO.read(file);
						Image dimg = img.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
						recipeImageJLabel.setIcon(new ImageIcon(dimg));
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			} else if (press.getSource() == addIngredientButton) {
				if ((ingredientNameField.getText().equals("")) || (ingredientQuantityField.getText().equals(""))
						|| (ingredientQuantityUnitsField.getText().equals("")) || (costField.getText().equals(""))) {
					JOptionPane.showMessageDialog(selfDialog, "You are missing values in your ingredient.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				for (int i = 0; i < ingredients.size(); i++) {
					if (ingredients.get(i).getName().toLowerCase().replaceAll(" ","")
							.equals(ingredientNameField.getText().toLowerCase().replaceAll(" ",""))) {
						JOptionPane.showMessageDialog(selfDialog, "You already have added an ingredient with the same name.",
								"Error", JOptionPane.ERROR_MESSAGE);
						return;
					}
				}

				Ingredient ingredient = new Ingredient(ingredientNameField.getText().toLowerCase(),
						Double.parseDouble(ingredientQuantityField.getText()), ingredientQuantityUnitsField.getText(),
						Double.parseDouble(costField.getText()));
				ingredients.add(ingredient);
				ingredientsListTableModel.addRow(ingredient);

			} else if (press.getSource() == deleteIngredientButton) {
				int selectedRow = ingredientsListTable.getSelectedRow();
				if (selectedRow < 0) {
					JOptionPane.showMessageDialog(selfDialog, "Please choose an ingredient to delete.", "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				int response = JOptionPane.showConfirmDialog(selfDialog, "Are you sure you want to delete this ingredient?",
						"Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				if (response == JOptionPane.NO_OPTION) {
					return;
				} else if (response == JOptionPane.YES_OPTION) {
					ingredients.remove(selectedRow);
					ingredientsListTableModel.removeRow(selectedRow);
				} else if (response == JOptionPane.CLOSED_OPTION) {
					return;
				}
			}
		}
	}

}
