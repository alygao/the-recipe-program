package theRecipeProgram;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

/**
 * ViewIngredientsDialog 
 * The dialog that will open when viewing ingredients
 * @author Alyssa Gao
 * @version 1.0
 * @since May 5, 2019
 */

public class ViewIngredientsDialog extends JDialog {

	/**
	 * the specific recipe whose ingredients are being displayed
	 */
	private Recipe recipe;
	
	/**
	 * reference this dialog as 'selfDialog'
	 */
	private JDialog selfDialog = this;

	/**
	 * the table model used to display the ingredients
	 */
	private IngredientsListTableModel ingredientListTableModel;
	
	/**
	 * the table used to display the ingredients
	 */
	private JTable ingredientListTable;
	
	/**
	 * the title label to allow users to know this is the ingredient list
	 */
	private JLabel ingredientListLabel;
	
	/**
	 * the background image for the dialog
	 */
	private ImageIcon background = null;

	/**
	 * constructor that initializes the user interface and recipe
	 * @param recipe the recipe whose ingredients are being displayed
	 */
	public ViewIngredientsDialog(Recipe recipe) {
		this.recipe = recipe;
		initUI();
	}

	/**
	 * initUI 
	 * Initializes the panel's attributes and loads the background image
	 */
	private void initUI() {
		setModalityType(ModalityType.APPLICATION_MODAL);

		setDefaultLookAndFeelDecorated(true);
		setTitle("Ingredient List");
		setSize(400, 400);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		getContentPane().add(panel);
		
		background = new ImageIcon(getClass().getResource("pink background.JPG"));
		JLabel backgroundLabel = new JLabel ();
		backgroundLabel.setIcon(background);
		backgroundLabel.setBounds(0, 0, 400, 400);

		ingredientListLabel = new JLabel("Ingredient List");
		ingredientListLabel.setBounds(150, 15, 100, 30);
		panel.add(ingredientListLabel);

		ingredientListTableModel = new IngredientsListTableModel();
		ingredientListTable = new JTable(ingredientListTableModel);
		ingredientListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ingredientListTable.setBounds(25, 50, 350, 300);
		ingredientListTableModel.addRows(recipe.getIngredients());

		JScrollPane recipeListScrollPane = new JScrollPane(ingredientListTable);
		recipeListScrollPane.setBounds(25, 50, 350, 300);
		panel.add(recipeListScrollPane);
		panel.add (backgroundLabel);
		
		setVisible(true);

	}

}
